SIMPLE PDF MAKER - ANDROID SOURCE PROJECT

Is project mein:
- Gallery/file picker se ek ya multiple images select hoti hain
- Har image PDF ke alag page par aati hai
- A4 page layout aur image aspect ratio preserve hota hai
- Android Save dialog se PDF save hoti hai
- Image upload/server ki zaroorat nahi; processing phone par hoti hai

IMPORTANT:
Yeh Android Studio source project hai, ready-made APK nahi. Is environment mein Android SDK/Gradle build tools maujood nahi the, isliye APK compile nahi ki gayi.

APK banane ke liye:
1. Android Studio wale computer par project folder open karein.
2. Gradle sync complete hone dein (internet chahiye).
3. Build > Build Bundle(s) / APK(s) > Build APK(s) chunein.
4. APK app/build/outputs/apk/debug/app-debug.apk mein milegi.

Mobile-only users:
Aap is ZIP ko phone mein rakh sakte hain, lekin is native project ko APK mein compile karne ke liye cloud Android build service ya computer chahiye. MIT App Inventor is Kotlin project ko directly import nahi kar sakta.
