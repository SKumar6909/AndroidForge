package com.skc.simplepdfmaker

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import java.io.InputStream
import kotlin.math.min

class MainActivity : ComponentActivity() {
    private val selectedImages = mutableListOf<Uri>()
    private lateinit var status: TextView
    private lateinit var listText: TextView
    private val navy = Color.rgb(7, 27, 53)
    private val cyan = Color.rgb(24, 201, 221)
    private val PICK_IMAGES = 101
    private val CREATE_PDF = 102
    private var pendingPdf: ByteArray? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(18))
            setBackgroundColor(Color.rgb(245, 249, 253))
        }
        val title = TextView(this).apply {
            text = "Simple PDF Maker"
            textSize = 27f
            setTextColor(navy)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(title, matchWrap())
        root.addView(TextView(this).apply {
            text = "Images ko select karke ek PDF banayein"
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(6), 0, dp(18))
        }, matchWrap())

        root.addView(makeButton("Select Images", cyan) { pickImages() }, buttonParams())
        root.addView(makeButton("Remove All Images", Color.rgb(220, 232, 241)) {
            selectedImages.clear(); updateList(); toast("Images list clear ho gayi")
        }, buttonParams())

        listText = TextView(this).apply {
            textSize = 15f; setTextColor(navy); setPadding(0, dp(18), 0, dp(8))
        }
        val scroll = ScrollView(this)
        scroll.addView(listText)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        root.addView(makeButton("Create PDF and Save", navy) { createPdf() }, buttonParams())
        status = TextView(this).apply {
            text = "Your images stay on your device."
            textSize = 12f; setTextColor(Color.DKGRAY); gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, 0)
        }
        root.addView(status, matchWrap())
        setContentView(root)
        updateList()
    }

    private fun makeButton(label: String, color: Int, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 16f
        setTextColor(if (color == cyan || color == navy) Color.WHITE else navy)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(color))
        setOnClickListener { action() }
    }

    private fun pickImages() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "image/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(Intent.createChooser(intent, "Select images"), PICK_IMAGES)
    }

    @Deprecated("Legacy callback retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGES && resultCode == Activity.RESULT_OK && data != null) {
            if (data.clipData != null) {
                val clip = data.clipData!!
                for (i in 0 until clip.itemCount) {
                    val uri = clip.getItemAt(i).uri
                    if (!selectedImages.contains(uri)) selectedImages.add(uri)
                }
            } else data.data?.let { if (!selectedImages.contains(it)) selectedImages.add(it) }
            updateList()
        } else if (requestCode == CREATE_PDF && resultCode == Activity.RESULT_OK) {
            val uri = data?.data
            val bytes = pendingPdf
            if (uri != null && bytes != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    status.text = "PDF saved successfully"
                    toast("PDF save ho gayi")
                } catch (e: Exception) { toast("Save nahi ho payi: ${e.message}") }
                finally { pendingPdf = null }
            }
        }
    }

    private fun updateList() {
        listText.text = if (selectedImages.isEmpty()) {
            "\nNo images selected yet.\nTap ‘Select Images’ and choose one or more photos."
        } else {
            "Selected images: ${selectedImages.size}\n\n" + selectedImages.mapIndexed { i, uri -> "${i + 1}. ${uri.lastPathSegment ?: "Image ${i + 1}"}" }.joinToString("\n\n")
        }
        status.text = "${selectedImages.size} image(s) selected"
    }

    private fun createPdf() {
        if (selectedImages.isEmpty()) { toast("Pehle images select karein"); return }
        try {
            val doc = PdfDocument()
            val pageW = 595
            val pageH = 842
            val margin = 28f
            selectedImages.forEachIndexed { index, uri ->
                val bitmap = decodeScaled(uri, 1800, 1800)
                    ?: throw IllegalStateException("Image ${index + 1} open nahi hui")
                val pageInfo = PdfDocument.PageInfo.Builder(pageW, pageH, index + 1).create()
                val page = doc.startPage(pageInfo)
                page.canvas.drawColor(Color.WHITE)
                val availableW = pageW - 2 * margin
                val availableH = pageH - 2 * margin
                val scale = min(availableW / bitmap.width.toFloat(), availableH / bitmap.height.toFloat())
                val drawW = bitmap.width * scale
                val drawH = bitmap.height * scale
                val left = (pageW - drawW) / 2f
                val top = (pageH - drawH) / 2f
                val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                page.canvas.drawBitmap(bitmap, null, RectF(left, top, left + drawW, top + drawH), paint)
                doc.finishPage(page)
                bitmap.recycle()
            }
            val out = java.io.ByteArrayOutputStream()
            doc.writeTo(out)
            doc.close()
            pendingPdf = out.toByteArray()
            val create = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/pdf"
                putExtra(Intent.EXTRA_TITLE, "SimplePDF_${System.currentTimeMillis()}.pdf")
            }
            startActivityForResult(create, CREATE_PDF)
        } catch (e: Exception) {
            toast("PDF nahi bani: ${e.message ?: "Unknown error"}")
        }
    }

    private fun decodeScaled(uri: Uri, maxW: Int, maxH: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > maxW * 2 || bounds.outHeight / sample > maxH * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.RGB_565 }
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun buttonParams() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
}
