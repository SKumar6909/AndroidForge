package com.pharmaknowledge.simplepdfmaker

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private val selectedImages = mutableListOf<Uri>()
    private lateinit var status: TextView
    private lateinit var fileName: EditText

    private val imagePicker = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris != null && uris.isNotEmpty()) {
            selectedImages.clear()
            selectedImages.addAll(uris)
            status.text = "${selectedImages.size} image(s) selected"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(Color.rgb(245, 248, 252))
        }

        val title = TextView(this).apply {
            text = "Simple PDF Maker"
            textSize = 27f
            setTextColor(Color.rgb(18, 43, 74))
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 12)
        }
        root.addView(title, matchWidth())

        val subtitle = TextView(this).apply {
            text = "Select photos and turn them into one PDF"
            textSize = 15f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }
        root.addView(subtitle, matchWidth())

        fileName = EditText(this).apply {
            hint = "PDF file name (e.g. MyDocument)"
            setSingleLine(true)
            setText("MyDocument")
            textSize = 16f
            setPadding(14, 12, 14, 12)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(fileName, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val choose = Button(this).apply {
            text = "1. Select Images"
            setOnClickListener { imagePicker.launch(arrayOf("image/*")) }
        }
        val chooseParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        chooseParams.topMargin = 20
        root.addView(choose, chooseParams)

        val create = Button(this).apply {
            text = "2. Create PDF"
            setOnClickListener { createPdf() }
        }
        val createParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        createParams.topMargin = 10
        root.addView(create, createParams)

        status = TextView(this).apply {
            text = "No images selected yet"
            textSize = 15f
            setTextColor(Color.rgb(40, 70, 100))
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        root.addView(status, matchWidth())

        val note = TextView(this).apply {
            text = "PDFs are saved in the Downloads folder. Images are processed on your device."
            textSize = 13f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, 30, 0, 0)
        }
        root.addView(note, matchWidth())

        setContentView(root)
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun createPdf() {
        if (selectedImages.isEmpty()) {
            Toast.makeText(this, "Please select at least one image first", Toast.LENGTH_LONG).show()
            return
        }

        val cleanName = fileName.text.toString().trim()
            .replace(Regex("[^A-Za-z0-9 _-]"), "")
            .ifBlank { "MyDocument" }
        val pdf = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val margin = 28f

        try {
            selectedImages.forEachIndexed { index, uri ->
                val bitmap = contentResolver.openInputStream(uri)?.use { input ->
                    BitmapFactory.decodeStream(input)
                } ?: throw IllegalStateException("Could not read image ${index + 1}")

                val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create()
                val page = pdf.startPage(pageInfo)
                val canvas: Canvas = page.canvas
                canvas.drawColor(Color.WHITE)

                val available = RectF(
                    margin,
                    margin,
                    pageWidth - margin,
                    pageHeight - margin
                )
                val scale = minOf(
                    available.width() / bitmap.width.toFloat(),
                    available.height() / bitmap.height.toFloat()
                )
                val drawWidth = bitmap.width * scale
                val drawHeight = bitmap.height * scale
                val left = (pageWidth - drawWidth) / 2f
                val top = (pageHeight - drawHeight) / 2f
                val dest = RectF(left, top, left + drawWidth, top + drawHeight)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                canvas.drawBitmap(bitmap, null as Rect?, dest, paint)
                pdf.finishPage(page)
                bitmap.recycle()
            }

            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "$cleanName.pdf")
                put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SimplePDFMaker")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
            }
            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Downloads.EXTERNAL_CONTENT_URI
            } else {
                MediaStore.Files.getContentUri("external")
            }
            val outputUri = contentResolver.insert(collection, values)
                ?: throw IllegalStateException("Could not create PDF file")
            contentResolver.openOutputStream(outputUri)?.use { output ->
                pdf.writeTo(output)
            } ?: throw IllegalStateException("Could not save PDF")

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                contentResolver.update(outputUri, done, null, null)
            }
            status.text = "PDF created: $cleanName.pdf\nSaved in Downloads/SimplePDFMaker"
            Toast.makeText(this, "PDF saved in Downloads", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            status.text = "Could not create PDF. Please try fewer/smaller images."
            Toast.makeText(this, "PDF error: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
        } finally {
            pdf.close()
        }
    }
}
