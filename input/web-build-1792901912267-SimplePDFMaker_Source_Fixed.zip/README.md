# Simple PDF Maker

A simple Android app that selects multiple images and saves them as a single A4-sized PDF in Downloads/SimplePDFMaker.

## Build
This is an Android Gradle project. Open it in Android Studio or upload the ZIP to a compatible Android build service such as AndroidForge.

## Features
- Select multiple images from the phone
- Arrange images in the order selected by the Android picker
- One image per A4 PDF page, preserving aspect ratio
- Save the resulting PDF locally on the device
- No account or network access required by the app itself
